//1.导包
import Vue from 'vue' //相当于 var Vue = require('vue')

//2.导入App.vue
import App from './App.vue'

//3.创建我们的根实例(一个项目只有一个)
new Vue({
    el:'#app',
    render:function(createElement){//createElement是一个函数
        return createElement(App)
    }
})
